# DuxOS Node Registry - Quick Start Guide

## Prerequisites
- Python 3.8+
- Git
- Flopcoin Core (v2.x)
- Ubuntu/Debian system (for desktop environment)

## Installation

1. **Clone the repository:**
   ```bash
   git clone https://github.com/ducks-github/Dux_OS.git
   cd Dux_OS
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   pip install -r requirements_desktop.txt
   ```

3. **Install Flopcoin Core:**
   - Download from: https://github.com/Flopcoin/Flopcoin/releases
   - Extract and install to /usr/local/bin

4. **Setup Flopcoin daemon:**
   ```bash
   python scripts/setup_flopcoin.py
   ```

5. **Setup Desktop Environment (Optional):**
   ```bash
   sudo python scripts/setup_desktop.py
   ```

6. **Test integration:**
   ```bash
   python scripts/test_real_flopcoin.py
   ```

## Configuration

- Edit `config/config.yaml` for wallet settings
- Edit `config/registry.yaml` for registry settings

## Usage

### Command Line
- Start the registry: `python -m duxos_registry.main`
- Use wallet CLI: `python -m duxos_wallet.cli`

### Desktop Environment
- Start DuxOS Desktop: `python desktop/desktop_manager.py`
- Or login to the desktop environment after setup

## Support

- Documentation: See `docs/` directory
- Issues: https://github.com/ducks-github/Dux_OS/issues

---
Generated on: 2025-07-04 18:03:43
Version: v2.2.0
